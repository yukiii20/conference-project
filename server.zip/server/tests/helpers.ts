import sharp from 'sharp'
import { pool } from '../src/db/pool.js'
import { hashPassword } from '../src/modules/auth/service.js'
import { generateToken, sha256 } from '../src/utils/crypto.js'

export async function pngBuffer(): Promise<Buffer> {
  return sharp({ create: { width: 4, height: 4, channels: 3, background: { r: 10, g: 20, b: 30 } } })
    .png()
    .toBuffer()
}

export async function jpgBuffer(): Promise<Buffer> {
  return sharp({ create: { width: 4, height: 4, channels: 3, background: { r: 200, g: 100, b: 50 } } })
    .jpeg()
    .toBuffer()
}

export function pdfBuffer(): Buffer {
  return Buffer.from('%PDF-1.4\n1 0 obj\n<< >>\nendobj\n%%EOF')
}

export function exeBuffer(): Buffer {
  return Buffer.concat([Buffer.from('MZ'), Buffer.alloc(200, 0)])
}

export function oversizedBuffer(bytes: number): Buffer {
  return Buffer.alloc(bytes, 1)
}

/**
 * Wipes every row this phase's tests can create, in FK-safe order (children
 * before parents). Deliberately leaves audit_logs alone — its triggers block
 * DELETE unconditionally, by design (see database/03_triggers.sql) — and
 * leaves reference data (roles, permissions, deadline_types, email_templates)
 * alone since those come from 02_reference_data.sql, not from tests.
 */
export async function resetDatabase(): Promise<void> {
  await pool.query('DELETE FROM email_logs')
  await pool.query('DELETE FROM role_requests')
  await pool.query('DELETE FROM conference_members')
  await pool.query('DELETE FROM conference_deadlines')
  await pool.query('DELETE FROM conference_settings')
  await pool.query('DELETE FROM conference_sessions')
  await pool.query('DELETE FROM rooms')
  await pool.query('DELETE FROM conference_tracks')
  await pool.query('DELETE FROM conference_supporters')
  await pool.query('DELETE FROM conferences')
  await pool.query('DELETE FROM auth_tokens')
  await pool.query('DELETE FROM auth_sessions')
  await pool.query('DELETE FROM users')
}

export async function createUser(input: {
  email: string
  password: string
  fullName?: string
  phone?: string
  status?: 'active' | 'suspended' | 'deactivated'
}): Promise<string> {
  const passwordHash = await hashPassword(input.password)
  await pool.query('INSERT INTO users (email, password_hash, full_name, phone, status) VALUES (?, ?, ?, ?, ?)', [
    input.email,
    passwordHash,
    input.fullName ?? 'Test User',
    input.phone ?? '+9779812345678',
    input.status ?? 'active',
  ])
  const [rows] = await pool.query('SELECT id FROM users WHERE email = ? LIMIT 1', [input.email])
  return (rows as Array<{ id: string }>)[0]!.id
}

export async function makePlatformAdmin(userId: string): Promise<void> {
  await pool.query('INSERT INTO platform_user_roles (user_id, role_code) VALUES (?, ?)', [userId, 'admin'])
}

export async function createConference(overrides: Partial<Record<string, unknown>> = {}): Promise<string> {
  const suffix = Math.random().toString(36).slice(2, 8)
  const slug = (overrides.slug as string) ?? `test-conf-${suffix}`
  const code = (overrides.code as string) ?? `TC${suffix}`.toUpperCase().slice(0, 10)
  await pool.query(
    `INSERT INTO conferences (slug, code, name, start_date, end_date, status, social_links)
     VALUES (?, ?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 DAY), ?, JSON_OBJECT())`,
    [slug, code, (overrides.name as string) ?? 'Test Conference', (overrides.status as string) ?? 'submission_open'],
  )
  const [rows] = await pool.query('SELECT id FROM conferences WHERE slug = ? LIMIT 1', [slug])
  return (rows as Array<{ id: string }>)[0]!.id
}

export async function addConferenceMember(
  conferenceId: string,
  userId: string,
  roleCode: string,
  status: 'active' | 'removed' = 'active',
): Promise<void> {
  await pool.query(
    `INSERT INTO conference_members (conference_id, user_id, role_code, status) VALUES (?, ?, ?, ?)`,
    [conferenceId, userId, roleCode, status],
  )
}

/**
 * Inserts an invitation token directly (bypassing the invite-convenor
 * service), so tests can exercise accept-invitation without needing to
 * intercept the console-logged link, and can test expiry without mocking
 * time.
 */
export async function createInvitationToken(userId: string, opts: { expired?: boolean } = {}): Promise<string> {
  const rawToken = generateToken()
  const interval = opts.expired ? 'DATE_SUB(NOW(3), INTERVAL 1 HOUR)' : 'DATE_ADD(NOW(3), INTERVAL 7 DAY)'
  await pool.query(
    `INSERT INTO auth_tokens (user_id, purpose, token_hash, expires_at) VALUES (?, 'invitation', ?, ${interval})`,
    [userId, sha256(rawToken)],
  )
  return rawToken
}

/** A user created with no password yet, as the convenor-invite endpoint creates one. */
export async function createPendingInviteUser(input: {
  email: string
  fullName?: string
  phone?: string
}): Promise<string> {
  await pool.query('INSERT INTO users (email, full_name, phone) VALUES (?, ?, ?)', [
    input.email,
    input.fullName ?? 'Invited User',
    input.phone ?? '+9779812345679',
  ])
  const [rows] = await pool.query('SELECT id FROM users WHERE email = ? LIMIT 1', [input.email])
  return (rows as Array<{ id: string }>)[0]!.id
}

export async function createRoleRequest(
  userId: string,
  conferenceId: string,
  roleCode: string,
  status: 'pending' | 'approved' | 'rejected' | 'cancelled' = 'pending',
): Promise<string> {
  await pool.query(`INSERT INTO role_requests (user_id, conference_id, role_code, status) VALUES (?, ?, ?, ?)`, [
    userId,
    conferenceId,
    roleCode,
    status,
  ])
  const [rows] = await pool.query(
    'SELECT id FROM role_requests WHERE user_id = ? AND conference_id = ? AND role_code = ? LIMIT 1',
    [userId, conferenceId, roleCode],
  )
  return (rows as Array<{ id: string }>)[0]!.id
}
